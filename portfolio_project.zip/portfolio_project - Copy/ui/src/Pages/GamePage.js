import React from 'react';
import './GamePage.css';
import Scoreboard from '../Components/Scoreboard';
import GuessInput from '../Components/GuessInput';
import ImageGenerator from '../Components/ImageGenerator';
import Timer from '../Components/Timer';
import Results from '../Components/Results';
import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import MistakeCounter from '../Components/MistakeCounter';
import SkipPokemonButton from '../Components/SkipPokemonButton';

function GamePage() {
  const [isGameStarted, setGameStarted] = useState(false);
  const [currentImageName, setCurrentImageName] = useState('');
  const [userCorrectGuess, setUserCorrectGuess] = useState(false);
  const [userScore, setUserScore] = useState(0);
  const [guessedPokemon, setGuessedPokemon] = useState([]);
  const [wronglyGuessedPokemon, setWronglyGuessedPokemon] = useState([]);
  const [isTimerExpired, setIsTimerExpired] = useState(false);
  const [startingTimer, setStartingTimer] = useState(0);
  const [result, setResult] = useState(null);
  const [totalTimeSpent, setTotalTimeSpent] = useState(0);
  const [userMistakes, setUserMistakes] = useState(0);
  const [userSkips, setUserSkips] = useState(3);
  const [guessTime, setGuessTime] = useState(0);
  const navigate = useNavigate();

  const handleSkipPokemon = () => {
    // Check if the user has any skips available
    if (userSkips > 0) {
      setUserCorrectGuess(true);
      setUserSkips(userSkips - 1); // Decrement the number of skips remaining
    } else {
      console.log('No skips available!');
    }
  };


  const handlePlayAgain = () => {
    setStartingTimer(0); // Reset the starting timer
    setIsTimerExpired(false); // Reset the timer expiry state
    setUserMistakes(0); // Reset user mistakes
    setGameStarted(true); // Start the game again
    setUserScore(0); // Reset user score
    setGuessedPokemon([]); // Reset guessed Pokemon
    setUserSkips(0);
    setResult(null); // Reset result
    setGuessTime(0);
  };

  const handleReturnHome = () => {
    // Implement the logic to return to the home screen here
    navigate('/');
  };

  useEffect(() => {
      setGameStarted(true);
  }, []);

  return (
    <div className="game-page">
      <h1>Who's that Pokemon!?</h1>
      <div className="timer">
        <Timer
          startingTimer={startingTimer}
          setStartingTimer={setStartingTimer}
          userMistakes={userMistakes}
          setTotalTimeSpent={setTotalTimeSpent}
          setIsTimerExpired={setIsTimerExpired}
          isTimerExpired={isTimerExpired}
        />
      </div>
      <div className="mistake-counter">
        <MistakeCounter
          userMistakes={userMistakes}
          userSkips={userSkips}
        />
      </div>
      <div className="skip-button">
        <SkipPokemonButton
          onSkipPokemon = {handleSkipPokemon}
        />
      </div>
      <div className="home-button">
        <button onClick={handleReturnHome}>Return to Home Screen</button>
      </div>
      <div classname="results">
        <Results
          userMistakes={userMistakes}
          userScore = {userScore}
          guessedPokemon = {guessedPokemon}
          wronglyGuessedPokemon={wronglyGuessedPokemon}
          playAgain={handlePlayAgain}
          returnHome={handleReturnHome}
          totalTimeSpent={totalTimeSpent}
        />
      </div>
      <div className="pokemon-image">
        <ImageGenerator
          gameStarted = {isGameStarted}
          setCurrentImageName={setCurrentImageName}
          userCorrectGuess={userCorrectGuess}
          setUserCorrectGuess={setUserCorrectGuess}
          guessedPokemon={guessedPokemon}
        />
      </div>
      <div className="input-bar">
        <GuessInput
          result={result}
          setResult={setResult}
          currentImageName={currentImageName}
          setUserCorrectGuess={setUserCorrectGuess}
          setUserScore={setUserScore}
          userScore = {userScore}
          setGuessedPokemon={setGuessedPokemon}
          wronglyGuessedPokemon={wronglyGuessedPokemon}
          setWronglyGuessedPokemon={setWronglyGuessedPokemon}
          userMistakes={userMistakes}
          setUserMistakes={setUserMistakes}
          guessTime={guessTime}
          setGuessTime={setGuessTime}
          startingTimer={startingTimer}
        />
      </div>
      <div className="scoreboard">
        <Scoreboard
          userScore={userScore}
          guessedPokemon={guessedPokemon}
        />
      </div>
    </div>

  )
}

export default GamePage;