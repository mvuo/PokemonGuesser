import React, { useState } from 'react';
import StartMenu from '../Components/StartMenu'
import PokemonCarousel from '../Components/PokemonCarousel'
import pokemonLogo from '../images/pokemon-logo.png';
import './HomePage.css'
import music from './OriginalPokerap.mp3'


function HomePage() {
    return (
        <div className="homepage-wrapper">
          <div className="audio-player">
            <audio controls autoPlay loop>
              <source src={music} type="audio/mpeg" />
              Your browser does not support the audio element.
            </audio>
          </div>
          <img src={pokemonLogo} alt="Pokemon Logo"/>
          <h1>Pokemon Guessing Game!</h1>
          <StartMenu />
          <PokemonCarousel />
        </div>
      );
}

export default HomePage;