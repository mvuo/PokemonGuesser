import React from 'react'
import InstructionPopup from './instructions'
import OptionPopup from './options'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom';

import './StartMenu.css'

function StartMenu() {
  const [instructionsPopup, setInstructionsPopup] = useState(false);
  const [optionsPopup, setOptionsPopup] = useState(false);
  const navigate = useNavigate();

  const handleStartGame = () => {
    navigate('/game')
  }

    return (
        <div className="start-buttons">

        <button className="start-button" onClick={handleStartGame}>
          Start
        </button>

        <button className="instructions-button" onClick={() => setInstructionsPopup(true)}>
          Instructions
        </button>
        <InstructionPopup trigger={instructionsPopup} setTrigger={setInstructionsPopup}/>

        <button className="options-button" onClick={() => setOptionsPopup(true)}>
          Options
        </button>
        <OptionPopup trigger={optionsPopup} setTrigger={setOptionsPopup}/>

      </div>
    )
}

export default StartMenu;