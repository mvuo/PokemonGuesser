import React from 'react'
import './popup.css'

function instructions(props) {
  return (props.trigger) ? (
    <div className="options">
        <div className="popup-inner">
            <h1>Implementation TBD</h1>

            <button className="close-btn" onClick={() => props.setTrigger(false) }>
                Close
            </button>
            { props.children }
        </div>
    </div>
  ) : "";
}

export default instructions