import React from 'react';
import './MistakeCounter.css';

function MistakeCounter({ userMistakes, userSkips }) {
    let total = 3 - userMistakes;
    return (
        <div className="mistake-counter">
        <h3>Remaining mistakes available: {total}</h3>
        <h3>Remaining skips available: {userSkips}</h3>
        </div>
    );
}

export default MistakeCounter;
