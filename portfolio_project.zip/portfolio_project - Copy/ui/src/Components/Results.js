import React from 'react';
import './Results.css'

function ResultsPage({ userMistakes, userScore, guessedPokemon, wronglyGuessedPokemon, playAgain, returnHome, totalTimeSpent }) {
  return (userMistakes === 3) ? (
    <div className = "results">
        <div className="popup-inner">
            <h2>Results</h2>
            <p>Total Score: {userScore}</p>
            <p>Correctly Identified Pokémon: {guessedPokemon.length}</p>
            <p>Total Time Spent: {totalTimeSpent} seconds</p>
            <p>Correctly guessed:</p>
            <ul>
                {guessedPokemon.map((pokemon, index) => (
                <li key={index}>{pokemon}</li>
                ))}
            </ul>
            <p>Incorrectly guessed:</p>
            <ul>
                {wronglyGuessedPokemon.map((pokemon, index) => (
                <li key={index}>{pokemon}</li>
                ))}
            </ul>
            {/* Play Again button */}
            <button onClick={playAgain}>Play Again</button>
            {/* Return to Home Screen button */}
            <button onClick={returnHome}>Return to Home Screen</button>
        </div>
    </div>
  ) : "";
}

export default ResultsPage;
