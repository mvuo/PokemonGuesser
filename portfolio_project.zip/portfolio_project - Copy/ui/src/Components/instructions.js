import React from 'react'
import './popup.css'

function instructions(props) {
  return (props.trigger) ? (
    <div className="instructions">
        <div className="popup-inner">
            <h2 class="headings">Instructions</h2>
            <h3>Try to figure out as many pokemon as you can!</h3>
            <h3>You will have 3 mistakes and 3 skips max to guess!</h3>
            <h3>Type in the name of the pokemon and hit Enter.</h3>
            <h3>Every pokemon you identify earns +1 point. Guesses in 5s earns +2. Guesses in 3s earns +5!</h3>
            <h3>Goodluck!</h3>
            <button className="close-btn" onClick={() => props.setTrigger(false) }>
                Close
            </button>
            { props.children }
        </div>
    </div>
  ) : "";
}

export default instructions;