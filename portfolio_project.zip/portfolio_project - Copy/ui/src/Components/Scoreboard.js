import React from 'react';
import './scoreboard.css';

function Scoreboard({ userScore, guessedPokemon }) {
  const maxPokemonPerRow = 20; // Maximum number of Pokemon per row

  const rows = Math.ceil(guessedPokemon.length / maxPokemonPerRow); // Calculate the number of rows needed

  return (
    <div className='scoreboard'>
      <h2>Scoreboard</h2>
      <p>Score: {userScore}</p>
      {Array.from({ length: rows }, (_, index) => (
        <div key={index} className='scoreboard-row'>
          {guessedPokemon
            .slice(index * maxPokemonPerRow, (index + 1) * maxPokemonPerRow)
            .map((pokemon, pokemonIndex) => (
              <img
                key={pokemonIndex}
                src={`/pokemon-images/${pokemon}.png`}
                alt={`Pokemon ${pokemon}`}
                className='scoreboard-image'
              />
            ))}
        </div>
      ))}
    </div>
  );
}

export default Scoreboard;