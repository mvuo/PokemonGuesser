import React, { useState } from 'react';
import './GuessInput.css'

function GuessInput({ result, setResult, currentImageName, setUserCorrectGuess, setUserScore, userScore, setGuessedPokemon, wronglyGuessedPokemon, setWronglyGuessedPokemon, userMistakes, setUserMistakes, guessTime, setGuessTime, startingTimer }) {
  const [userGuess, setUserGuess] = useState('');
  const handleInputChange = (event) => {
    setUserGuess(event.target.value);
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      checkGuess();
      setUserGuess('');
    }
  };

  const checkGuess = () => {
    if (userGuess.toLowerCase() === currentImageName.toLowerCase()) {
      if (startingTimer - guessTime < 3) {
        setResult("Holy smokes! +5 Points!");
        setUserScore(userScore + 3)
      } else if (startingTimer - guessTime < 5) {
        setResult("Pretty fast! +2 Points!");
        setUserScore(userScore + 2)
      } else {
        setResult('Correct!');
        setUserScore(userScore + 1)
      }
      setGuessTime(startingTimer);
      setUserCorrectGuess(true);
      setGuessedPokemon(prevGuessedPokemon => [...prevGuessedPokemon, currentImageName]);
    } else {
      setResult('Wrong!');
      setUserMistakes(userMistakes + 1);
      if (!wronglyGuessedPokemon.includes(currentImageName)) {
        setWronglyGuessedPokemon(prevGuessedPokemon => [...prevGuessedPokemon, currentImageName])
      }
    }
  };

  return (
    <div>
      <div className="input-container">
      <input
        type="text"
        value={userGuess}
        onChange={handleInputChange}
        onKeyDown={handleKeyPress}
        placeholder="Enter your guess..."
        className="input-bar"
      />
      </div>
      {result && <p>{result}</p>}
    </div>
  );
}

export default GuessInput;
