import React, { useEffect, useRef } from 'react';
import './Timer.css';

function Timer({ startingTimer, setStartingTimer, userMistakes, setTotalTimeSpent, setIsTimerExpired, isTimerExpired }) {
  const timerRef = useRef(null);

  useEffect(() => {
    if (!isTimerExpired) {
      timerRef.current = setInterval(() => {
        setStartingTimer((prevSeconds) => prevSeconds + 1);
      }, 1000);
    }

    return () => {
      clearInterval(timerRef.current);
    };
  }, [isTimerExpired, setStartingTimer]);

  useEffect(() => {
    if (userMistakes === 3) {
      setIsTimerExpired(true); // Update the isTimerExpired state here
    }
  }, [userMistakes, setIsTimerExpired]);

  useEffect(() => {
    setStartingTimer(0); // Reset the seconds when startingTimer changes
  }, [setStartingTimer]);

  useEffect(() => {
    setTotalTimeSpent(startingTimer);
  }, [startingTimer, setTotalTimeSpent]);

  // Format the seconds as "mm:ss"
  const formattedTime = `${Math.floor(startingTimer / 60)
    .toString()
    .padStart(2, '0')}:${(startingTimer % 60).toString().padStart(2, '0')}`;

  return (
    <div className="timer">
      <h3>Timer: {formattedTime}</h3>
    </div>
  );
}

export default Timer;
