import React from 'react';


function PauseButton({ onSkipPokemon }) {
  return (
    <div className="skip-button-wrapper">
      <button className="skip-button" onClick={onSkipPokemon}>
        Skip Current Pokemon
      </button>
    </div>
  );
}

export default PauseButton;
