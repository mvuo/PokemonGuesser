import React, { useEffect, useState } from 'react';

function ImageGenerator({ gameStarted, setCurrentImageName, userCorrectGuess, setUserCorrectGuess, guessedPokemon}) {
    const [imageUrl, setImageUrl] = useState('');


  useEffect(() => {
    const generateImage = async () => {
      try {
        if (gameStarted || userCorrectGuess) {
            let response = await fetch('http://localhost:3001/generate-image');
            let data = await response.json();
            while (guessedPokemon.includes(data.name)) {
                response = await fetch('http://localhost:3001/generate-image');
                data = await response.json();
            }
            setImageUrl(data.imageUrl);
            console.log(data.name);
            console.log(data.imageUrl);
            setCurrentImageName(data.name);
        }
      } catch (error) {
        console.error('Error fetching image URL:', error);
      }
      setUserCorrectGuess(false);
    };

    generateImage();
  }, [gameStarted, setCurrentImageName, userCorrectGuess, setUserCorrectGuess, guessedPokemon]);


  const imageStyle = {
    filter: 'brightness(0%)',
  }

  return (
    <div>
      {imageUrl ? (
        <img src={imageUrl} alt="Random Pokemon" style={imageStyle} />
      ) : (
        <span>Image will appear here!</span>
      )}
    </div>
  );
}

export default ImageGenerator;