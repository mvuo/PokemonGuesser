import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import './PokemonCarousel.css';
import imageUrls from './imageUrls'; // Import the imageUrls array

const PokemonCarousel = () => {
  const settings = {
    dots: false,
    infinite: true,
    speed: 1500,
    slidesToShow: 4,
    slidesToScroll: 1,
    centerMode: true,
    centerPadding: '800px',
    autoplay: true,
    autoplaySpeed: 0,
    cssEase: 'linear',
  };

  return (
    <div className="pokemon-carousel">
      <Slider {...settings}>
        {imageUrls.map(({ name, url }, index) => ( // Map over imageUrls
          <div key={index} className="pokemon-slide">
            <img src={url} alt={name} />
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default PokemonCarousel;
