const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();
const imageUrls = require('./imageUrls');
// Enable CORS for all routes
app.use(cors());

// Serve static files from the 'images' directory
app.use(express.static(path.join(__dirname, '../ui/public/pokemon-images')));

// API endpoint to generate an image URL
app.get('/generate-image', (req, res) => {
    // Generate a random number between 0 and the length of the imageUrls array
     const randomIndex = Math.floor(Math.random() * imageUrls.length);

    // Get the image URL corresponding to the random index
      const imageUrl = imageUrls[randomIndex].url;
      const imageName = imageUrls[randomIndex].name;
    // Send the image URL as a response
    res.json({ imageUrl, name: imageName });
  });





// Start the server
app.listen(3001, () => {
  console.log('Server listening on port 3001');
});
